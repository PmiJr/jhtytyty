<?php
/**
 * Template part for displaying sticky.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Furnicom_lite
 */

$utility          = furnicom_lite_utility()->utility;
$sticky           = furnicom_lite_sticky_label( false );

echo $sticky;
